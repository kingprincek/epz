<?php

namespace App\Http\Livewire;

use Livewire\Component;

class Services extends Component
{
    public function render()
    {
        return view('livewire.services')->layout('layouts.front');;
    }
}

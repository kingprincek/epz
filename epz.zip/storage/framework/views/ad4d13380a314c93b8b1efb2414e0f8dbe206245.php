<?php if($errors->any()): ?>
    <div <?php echo e($attributes); ?>>

        <div class="alert alert-warning">
           <?php echo e(__('Whoops! Something went wrong.')); ?>

        </div>
        <div class="font-medium text-red-600"></div>

        <ul class="list-group">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <li class="list-group-item">
                    <div class="alert alert-danger alert-dismissible">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                        <strong> <?php echo e($error); ?></strong>
                    </div>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\epz\resources\views/vendor/jetstream/components/validation-errors.blade.php ENDPATH**/ ?>
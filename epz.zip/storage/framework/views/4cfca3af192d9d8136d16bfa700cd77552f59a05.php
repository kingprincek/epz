<div>
    <div class="breadcrumbs-area position-relative mb-text-p">
        <div class="container">
            <div class="row">
                <div class="col-12 text-center">
                    <div class="breadcrumb-content position-relative section-content">
                        <h3 class="title">Youth Economic Forum</h3>
                        <ul>
                            <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
                            <li>yef</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container">
        <h2>Who we are</h2>

        <p>
            Taking into consideration the failure of traditional charity to enable people to solve their own problems over the
            long term, prompted by the spirit of selflessness, we do hereby pledge our commitment to form an organization, which make use
            of new blended financing development models, that is, patient capital, philanthropic funds and private sector investment combinations as a development tool. At the heart of this organization is a new commitment by young people to strive together for a better Zimbabwe and Africa as whole. Our organisation was founded on the, 18th of April, 2021 on the day of Zimbabwe’s National Independence day brought about by an organised militant effort by young people such as ourselves in bringing sovereignty to the natives of the land. Our revolution is intellectual, as we believe that continued economic growth requires that we intelligently package our ideas to the betterment of the development of Zimbabwe and Africa at large! As such we are an apolitical organisation
            focused on affirmative action of youth inclusion in the economics of the country and continent as a whole.
        </p>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\epz\resources\views/livewire/yef.blade.php ENDPATH**/ ?>
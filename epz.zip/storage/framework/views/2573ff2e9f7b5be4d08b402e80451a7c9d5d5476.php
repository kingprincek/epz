<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\epz\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>
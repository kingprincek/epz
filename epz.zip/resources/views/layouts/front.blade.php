<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Youth Economic Capital</title>

    <!-- Vendor CSS (Icon Font) -->
    <!--
<link rel="stylesheet" href="assets/css/vendor/fontawesome.min.css">
-->

    <!-- Plugins CSS (All Plugins Files) -->
    <!--
<link rel="stylesheet" href="assets/css/plugins/splitting.min.css">
<link rel="stylesheet" href="assets/css/plugins/animate.min.css">
<link rel="stylesheet" href="assets/css/plugins/jquery-ui.min.css">
<link rel="stylesheet" href="assets/css/plugins/nice-select.min.css">
<link rel="stylesheet" href="assets/css/plugins/swiper-bundle.min.css">
<link rel="stylesheet" href="assets/css/plugins/aos.min.css">
<link rel="stylesheet" href="assets/css/plugins/magnific-popup-min.css">
-->

    <!-- Main Style CSS -->
    <!-- <link rel="stylesheet" href="assets/css/style.css" />  -->


    <!-- Use the minified version files listed below for better performance and remove the files listed above -->
    <link rel="stylesheet" href="/yec/assets/css/vendor/vendor.min.css">
    <link rel="stylesheet" href="/yec/assets/css/plugins/plugins.min.css">
    <link rel="stylesheet" href="/yec/assets/css/style.min.css">
    <link rel="stylesheet" href="/yec/assets/css/custom.css">
    <style>
        .menu-text{
            color: #0C9DBF !important;
        }
        .service-icon{
            background-color: #0C9DBF !important;
        }

        .vertical-tab{
            font-family: 'Karla', sans-serif;
            display: table;
        }
        .vertical-tab p{
            font-size: 16px;
        }
        .vertical-tab .nav-tabs{
            display: table-cell;
            width: 25%;
            min-width: 25%;
            border: none;
            vertical-align: top;
        }
        .vertical-tab .nav-tabs li{ float: none; }
        .vertical-tab .nav-tabs li a{
            color: #555;
            background: #fff;
            font-size: 16px;
            font-weight: 500;
            letter-spacing: 0.5px;
            text-transform: uppercase;
            text-align: center;
            padding: 8px 7px 7px;
            margin: 0 10px 12px 0;
            border-radius: 30px;
            border: none;
            box-shadow: 0 0 5px rgba(0,0,0,0.1);
            overflow: hidden;
            position: relative;
            z-index: 1;
            transition: all 0.5s ease 0s;
        }
        .vertical-tab .nav-tabs li a:hover,
        .vertical-tab .nav-tabs li.active a,
        .vertical-tab .nav-tabs li.active a:hover{
            color: #fff;
            background: #fff;
            border: none;
        }
        .vertical-tab .nav-tabs li a:before{
            content: '';
            background-color: #1AA3C3;
            height: 7%;
            width: 100%;
            border-radius: 30px;
            position: absolute;
            left: 0;
            bottom: 0;
            z-index: -1;
            transition: all 0.3s ease-out 0s;
        }
        .vertical-tab .nav-tabs li a:hover:before,
        .vertical-tab .nav-tabs li.active a:before,
        .vertical-tab .nav-tabs li.active a:hover:before{
            height: 100%;
        }
        .vertical-tab .tab-content{
            color: #777;
            background: #fff;
            font-size: 14px;
            font-weight: 500;
            line-height: 21px;
            padding: 15px;
            border-radius: 5px;
            box-shadow: 0 0 5px rgba(0,0,0,0.1);
            display: table-cell;
        }
        .vertical-tab .tab-content h3{
            color: #1AA3C3;
            font-size: 22px;
            font-weight: 500;
            text-transform: capitalize;
            margin: 0 0 5px;
        }
        @media only screen and (max-width: 479px){
            .vertical-tab .nav-tabs{
                width: 100%;
                display: block;
            }
            .vertical-tab .nav-tabs li a{
                padding: 10px 25px 9px;
                margin: 0 0 12px;
            }
            .vertical-tab .tab-content{
                font-size: 14px;
                padding: 15px;
                display: block;
            }
        }

        /*team*/
        .heading.heading-icon {
            display: block;
        }
        .padding-lg {
            display: block;
            padding-top: 60px;
            padding-bottom: 60px;
        }
        .practice-area.padding-lg {
            padding-bottom: 55px;
            padding-top: 55px;
        }
        .practice-area .inner{
            border:1px solid #999999;
            text-align:center;
            margin-bottom:28px;
            padding:40px 25px;
        }
        .our-webcoderskull .cnt-block:hover {
            box-shadow: 0px 0px 10px rgba(0,0,0,0.3);
            border: 0;
        }
        .practice-area .inner h3{
            color:#3c3c3c;
            font-size:24px;
            font-weight:500;
            font-family: 'Poppins', sans-serif;
            padding: 10px 0;
        }
        .practice-area .inner p{
            font-size:14px;
            line-height:22px;
            font-weight:400;
        }
        .practice-area .inner img{
            display:inline-block;
        }


        .our-webcoderskull{
            /*background: url("http://www.webcoderskull.com/img/right-sider-banner.png") no-repeat center top / cover;*/

        }
        .our-webcoderskull .cnt-block{
            float:left;
            width:100%;
            background:#fff;
            padding:30px 20px;
            text-align:center;
            border:2px solid #d5d5d5;
            margin: 0 0 28px;
        }
        .our-webcoderskull .cnt-block figure{
            width:148px;
            height:148px;
            border-radius:100%;
            display:inline-block;
            margin-bottom: 15px;
        }
        .our-webcoderskull .cnt-block img{
            width:148px;
            height:148px;
            border-radius:100%;
        }
        .our-webcoderskull .cnt-block h3{
            color:#2a2a2a;
            font-size:20px;
            font-weight:500;
            padding:6px 0;
            text-transform:uppercase;
        }
        .our-webcoderskull .cnt-block h3 a{
            text-decoration:none;
            color:#2a2a2a;
        }
        .our-webcoderskull .cnt-block h3 a:hover{
            color:#337ab7;
        }
        .our-webcoderskull .cnt-block p{
            color:#2a2a2a;
            font-size:13px;
            line-height:20px;
            font-weight:400;
        }
        .our-webcoderskull .cnt-block .follow-us{
            margin:20px 0 0;
        }
        .our-webcoderskull .cnt-block .follow-us li{
            display:inline-block;
            width:auto;
            margin:0 5px;
        }
        .our-webcoderskull .cnt-block .follow-us li .fa{
            font-size:24px;
            color:#767676;
        }
        .our-webcoderskull .cnt-block .follow-us li .fa:hover{
            color:#025a8e;
        }

        .row.heading h2 {
            color: #fff;
            font-size: 52.52px;
            line-height: 95px;
            font-weight: 400;
            text-align: center;
            margin: 0 0 40px;
            padding-bottom: 20px;
            text-transform: uppercase;
        }
    </style>
    @livewireStyles

</head>

<body>
<div id="preloader">
    <div class="preloader">
        <div class="spinner-border text-primary"></div>
    </div>
</div>

<!-- Header Area Start Here -->
<header class="main-header-area header-transparent header-sticky">
    <!-- Main Header Area Start -->
    <div class="main-header">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-2 col-xl-2 col-md-6 col-6">
                    <div class="header-logo d-flex align-items-center">
                        <a href="/">
                            <img class="nonsticky-logo img-full" src="/yec/assets/images/logo/logo.png" alt="Header Logo">
                            <img class="sticky-logo img-full" src="/yec/assets/images/logo/white-logo.png" alt="Header Logo">
                        </a>
                    </div>
                </div>
                <div class="col-lg-10 col-md-6 col-6 d-flex justify-content-end">
                    <nav class="main-nav d-none d-lg-flex">
                        <ul class="nav">
                            <li>
                                <a class="active" href="/">
                                    <span class="menu-text"> Home</span>

                                </a>

                            </li>
                            <li>
                                <a href="{{route('about')}}">
                                    <span class="menu-text">About</span>
                                </a>
                            </li>
                            <li>
                                <a href="{{route('yef-section')}}" target="_blank">
                                    <span class="menu-text">Yef</span>
                                </a>
                            </li>

                            <li>
                                <a href="{{route('services')}}">
                                    <span class="menu-text"> Service</span>
                                </a>
                            </li>
                            <li>
                                <a href=""f>
                                    <span class="menu-text"> Our Projects</span>

                                </a>

                            </li>
                            <li>
                                <a href="blog.html">
                                    <span class="menu-text"> Blog</span>

                                </a>

                            </li>
                            <li>
                                <a href="{{route('contact')}}">
                                    <span class="menu-text">Contact</span>
                                </a>
                            </li>
                            <li>
                                <a href="{{route('register')}}">
                                    <span class="menu-text"><b>Register</b></span>
                                </a>
                            </li>
                            <li>
                                <a href="{{route('login')}}">
                                    <span class="menu-text"><b>Login</b></span>
                                </a>
                            </li>

                        </ul>
                    </nav>

                </div>
            </div>
        </div>
    </div>
    <!-- Main Header Area End -->
    <!-- off-canvas mobile menu start -->
    <aside class="off-canvas-wrapper" id="mobileMenu">
        <div class="off-canvas-overlay"></div>
        <div class="off-canvas-inner-content">
            <div class="btn-close-off-canvas">
                <i class="fa fa-times"></i>
            </div>
            <div class="off-canvas-inner">
                <div class="offcanvas-widget-area">
                    <!-- Start Serach Box -->
                    <div class="search-box-wrap off-canvas-item">
                        <form action="#" method="post">
                            <input placeholder="Search..">
                            <button class="btn-search"><i class="fa fa-search"></i>
                            </button>
                        </form>
                    </div>
                    <!-- End Search Box -->
                    <!-- mobile menu start -->
                    <div class="mobile-navigation">
                        <!-- mobile menu navigation start -->
                        <nav>
                            <ul class="mobile-menu">
                                <li class="menu-item-has-children"><a href="#">Home</a>

                                </li>
                                <li><a href="about.html">About</a></li>
                                <li><a href="service.html">Service</a></li>
                                <li class="menu-item-has-children"><a href="#">Portfolio</a>
                                </li>
                                <li class="menu-item-has-children"><a href="#">Blog</a>
                                </li>
                                <li><a href="contact.html">Contact</a></li>
                            </ul>
                        </nav>
                        <!-- mobile menu navigation end -->
                    </div>
                    <!-- mobile menu end -->
                    <!-- Soclial Link Start -->
                    <div class="widget-social">
                        <a title="Facebook" href="#"><i class="fa fa-facebook-f"></i></a>
                        <a title="Twitter" href="#"><i class="fa fa-twitter"></i></a>
                        <a title="Linkedin" href="#"><i class="fa fa-linkedin"></i></a>
                        <a title="Youtube" href="#"><i class="fa fa-youtube"></i></a>
                        <a title="Vimeo" href="#"><i class="fa fa-vimeo"></i></a>
                    </div>
                    <!-- Social Link End -->
                </div>
            </div>
        </div>
    </aside>
    <!-- off-canvas menu end -->
    <!-- Offcanvas Serach Start -->
    <aside class="off-canvas-search-wrapper">
        <div class="off-canvas-overlay"></div>
        <div class="off-canvas-inner-content">
            <div class="off-canvas-inner">
                <form action="#" method="post">
                    <input type="search" placeholder="Search..">
                    <button class="search-btn"><i class="fa fa-search"></i></button>
                </form>
            </div>
        </div>
    </aside>
    <!-- Offcanvas Search End -->
    <!-- off-canvas menu start -->
    <aside class="off-canvas-menu-wrapper" id="sideMenu">
        <div class="off-canvas-overlay"></div>
        <div class="off-canvas-inner-content">
            <div class="off-canvas-inner">
                <!-- offcanvas widget area start -->
                <div class="offcanvas-widget-area">
                    <!-- Start Serach Box -->
                    <div class="search-box-wrap off-canvas-item">
                        <form action="#" method="post">
                            <input placeholder="Search..">
                            <button class="btn-search"><i class="fa fa-search"></i>
                            </button>
                        </form>
                    </div>
                    <!-- End Search Box -->
                    <ul class="menu-top-menu">
                        <li><span>Who We Are</span></li>
                    </ul>
                    <p class="desc-content">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                    <ul class="useful-link">
                        <li><a href="index.html">Home</a></li>
                        <li><a href="service.html">Service</a></li>
                        <li><a href="portfolio.html">Portfolio</a></li>
                        <li><a href="about.html">About Us</a></li>
                        <li><a href="contact.html">Contact Us</a></li>
                    </ul>
                    <div class="widget-social">
                        <ul class="menu-top-menu">
                            <li><span>Connect With Us</span></li>
                        </ul>
                        <a title="Facebook" href="#"><i class="fa fa-facebook-f"></i></a>
                        <a title="Twitter" href="#"><i class="fa fa-twitter"></i></a>
                        <a title="Linkedin" href="#"><i class="fa fa-linkedin"></i></a>
                        <a title="Youtube" href="#"><i class="fa fa-youtube"></i></a>
                        <a title="Vimeo" href="#"><i class="fa fa-vimeo"></i></a>
                    </div>
                </div>
                <!-- offcanvas widget area end -->
            </div>
            <div class="btn-close-off-canvas">
                <i class="fa fa-times"></i>
            </div>
        </div>
    </aside>
    <!-- off-canvas menu end -->
</header>
<!-- Header Area End Here -->
{{ $slot }}
<!-- Footer Section Start Here -->
<footer class="footer-section pt-90"
    <div class="footer-widget-area">
        <div class="container container-default custom-area">
            <div class="row">
                <div class="col-12 col-sm-12 col-md-12 col-lg-4 col-custom">
                    <div class="single-footer-widget m-0" data-aos="fade-up" data-aos-delay="300" data-aos-anchor-placement="bottom bottom">
                        <div class="footer-logo pb-3">
                            <a href="index.html">
                                <img src="/yec/assets/images/logo/logo.png" alt="Logo Image">
                            </a>
                        </div>
                        <p class="desc-content pt-3 pb-3">We are an impact investment company seeks to operate impact funds aligned with the philosophy of SDG
                            Financing – creating impact as well as the essential financial return.</p>
                        <!-- Soclial Link Start -->
                        <div class="widget-social pt-4">
                            <a title="Facebook" href="#"><i class="fa fa-facebook-f"></i></a>
                            <a title="Twitter" href="#"><i class="fa fa-twitter"></i></a>
                            <a title="Linkedin" href="#"><i class="fa fa-linkedin"></i></a>
                            <a title="Youtube" href="#"><i class="fa fa-youtube"></i></a>
                            <a title="Vimeo" href="#"><i class="fa fa-vimeo"></i></a>
                        </div>
                        <!-- Social Link End -->
                    </div>
                </div>
                <div class="col-12 col-sm-6 col-md-4 col-lg-3 col-custom">
                    <div class="single-footer-widget" data-aos="fade-up" data-aos-delay="400" data-aos-anchor-placement="bottom bottom">
                        <h2 class="widget-title">Our Servcie</h2>
                        <ul class="widget-list pt-3">
                            <li><a href="service.html">Business</a></li>
                            <li><a href="service.html">Growth</a></li>
                            <li><a href="service.html">Funding</a></li>

                        </ul>
                    </div>
                </div>
                <div class="col-12 col-sm-6 col-md-3 col-lg-2 col-custom">
                    <div class="single-footer-widget" data-aos="fade-up" data-aos-delay="500" data-aos-anchor-placement="bottom bottom">
                        <h2 class="widget-title">Quicklink</h2>
                        <ul class="widget-list pt-3">
                            <li><a href="index.html">Home</a></li>
                            <li><a href="about.html">About</a></li>
                            <li><a href="contact.html">Term Of Use</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-12 col-sm-12 col-md-5 col-lg-3 col-custom">
                    <div class="single-footer-widget" data-aos="fade-up" data-aos-delay="600" data-aos-anchor-placement="bottom bottom">
                        <h2 class="widget-title">Get in Touch</h2>
                        <div class="widget-body pt-3">
                            <p class="desc-content pb-3">Enter your email and receive the latest news from us.</p>
                            <div class="newsletter-form-wrap pt-4">
                                <form id="mc-form" class="mc-form d-flex position-relative">
                                    <input type="email" id="mc-email" class="form-control email-box rounded-0" placeholder="email@example.com" name="EMAIL">
                                    <button id="mc-submit" class="btn newsletter-btn position-absolute" type="submit"><i class="fa fa-envelope"></i></button>
                                </form>
                                <!-- mailchimp-alerts Start -->
                                <div class="mailchimp-alerts text-centre">
                                    <div class="mailchimp-submitting"></div><!-- mailchimp-submitting end -->
                                    <div class="mailchimp-success text-success"></div><!-- mailchimp-success end -->
                                    <div class="mailchimp-error text-danger"></div><!-- mailchimp-error end -->
                                </div>
                                <!-- mailchimp-alerts end -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="footer-copyright-area pt-5 border-top mt-90 mb-5">
        <div class="container custom-area">
            <div class="row">
                <div class="col-12 text-center col-custom">
                    <div class="copyright-content">
                        <p class="mb-0">Copyright © 2020 <a href="#">YEC</a> | Built</strong>&nbsp;by <a href="#">Bint</a>.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>
<!-- Footer Section End Here -->



<!-- Scroll Top Start Here -->
<a href="#" class="scroll-top" id="scroll-top">
    <i class="arrow-top fa fa-angle-double-up"></i>
    <i class="arrow-bottom fa fa-angle-double-up"></i>
</a>
<!-- Scroll Top End Here -->

<!-- Global Vendor, plugins JS -->

<!-- Vendors JS -->
<!--
<script src="assets/js/vendor/vendor.min.js"></script>
<script src="assets/js/vendor/jquery-3.5.1.min.js"></script>
<script src="assets/js/vendor/jquery-migrate-3.3.0.min.js"></script>
<script src="assets/js/vendor/modernizr-3.11.2.min.js"></script>
-->

<!-- Plugins JS -->
<!--
<script src="assets/js/plugins/splitting.min.js"></script>
<script src="assets/js/plugins/swiper-bundle.min.js"></script>
<script src="assets/js/plugins/waypoints.min.js"></script>
<script src="assets/js/plugins/counter.min.js"></script>
<script src="assets/js/plugins/aos.min.js"></script>
<script src="assets/js/plugins/jquery.magnific-popup.min.js"></script>
<script src="assets/js/plugins/jquery.vide.min.js"></script>
<script src="assets/js/plugins/masonry.min.js"></script>
<script src="assets/js/plugins/theia-sticky-sidebar.min.js"></script>
<script src="assets/js/plugins/nice-select.min.js"></script>
<script src="assets/js/plugins/jquery.ajaxchimp.min.js"></script>
<script src="assets/js/plugins/jquery-ui.min.js"></script>
-->

<!-- Use the minified version files listed below for better performance and remove the files listed above -->
<script src="/yec/assets/js/vendor/vendor.min.js"></script>
<script src="/yec/assets/js/plugins/plugins.min.js"></script>

<!--Main JS-->
<script src="/yec/assets/js/main.js"></script>
@livewireScripts
</body>

</html>

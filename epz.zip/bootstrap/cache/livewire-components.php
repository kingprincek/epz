<?php return array (
  'about' => 'App\\Http\\Livewire\\About',
  'contact' => 'App\\Http\\Livewire\\Contact',
  'home' => 'App\\Http\\Livewire\\Home',
  'quiz' => 'App\\Http\\Livewire\\Quiz',
  'services' => 'App\\Http\\Livewire\\Services',
  'yef' => 'App\\Http\\Livewire\\Yef',
);